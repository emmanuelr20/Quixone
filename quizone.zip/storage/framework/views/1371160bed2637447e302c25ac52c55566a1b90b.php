<div class="modal fade" tabindex="-1" role="dialog" id="game_type">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title">Select Quiz Type</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>
        <br>
        <?php $__empty_1 = true; $__currentLoopData = $quiz_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="row">
            <div class="col-md-1"></div>
            <div class="col-lg-10">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title"><?php echo e($quiz_type->title); ?></h5>
                  <p class="card-text"><?php echo e($quiz_type->description); ?></p>
                  <a href="<?php echo e(route('select_subject', $quiz_type->id)); ?>" class="card-link pull-right">Play Now</a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="row">
            <div class="col-md-1"></div>
            <div class="col-lg-10">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">There is currently no availble quiz</h5>
                </div>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div>