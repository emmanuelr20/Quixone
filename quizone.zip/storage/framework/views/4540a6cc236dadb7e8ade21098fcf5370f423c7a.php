<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
  <!-- Content Wrapper. Contains page content -->
  <div class="wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="identity text-center">
        <div class="text-content">
              <h1 class=""> Quixone </h1>
              <h5 class="">Pick Three Topics Now To Win Instantly.</h5>
              
        </div>
      </div>
      
      
    </section>
    <!-- /.content -->
  
  
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-center m-auto" id="testimonialSlider">
          <h2>Testimonials</h2>
          <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Carousel indicators -->
            <?php if($testimonies->count()): ?>
            <ol class="carousel-indicators">
                <?php for($i = 0; $i < $testimonies->count(); $i++): ?>
                    <li data-target="#myCarousel" data-slide-to="<?php echo e($i); ?>" class="active" <?php echo e($j = 0); ?>></li>
                <?php endfor; ?>
            </ol>   
            
            <div class="carousel-inner">
              
                <?php $__currentLoopData = $testimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Wrapper for carousel items -->  
                    <div class="item carousel-item <?php echo e(!$j ? 'active' : ''); ?>">
                        <?php if($testimony->user->avatar): ?>
                            <div class="img-box"><img src="<?php echo e(asset('dist/img/' . $testimony->user->avatar)); ?>" alt="avatar"></div>
                        <?php else: ?>
                            <div class="img-box"><img src="<?php echo e(asset('dist/img/avatar.png')); ?>" alt="avatar"></div>
                        <?php endif; ?>
                        <p class="testimonial" <?php echo e($j = $j + 1); ?>><?php echo e($testimony->body); ?></p>
                        <p class="overview"><b><?php echo e($testimony->user->name); ?></b>, <?php echo e($testimony->user->username); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </div>
            

            <!-- Carousel controls -->
            <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
              <i class="fa fa-angle-left"></i>
            </a>
            <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
              <i class="fa fa-angle-right"></i>
            </a>
          </div>
          <?php else: ?>
          <h4 class="text-center">No testimonies yet!</h4>
          <br>
          <?php endif; ?>

        </div>
      </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.primary', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>