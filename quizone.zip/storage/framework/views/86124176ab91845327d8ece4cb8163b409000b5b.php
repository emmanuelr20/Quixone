<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>QuizOne | <?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="/plugins/iCheck/square/blue.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/custom.css')); ?>">
</head>

<body class="hold-transition <?php echo $__env->yieldContent('name'); ?>">
    <div class="login-box">
          <div class="login-logo">
            <a href="./"><b>Quiz</b>One</a>
          </div>
          <!-- /.login-logo -->
<?php echo $__env->yieldContent('content'); ?>

</div>
<!-- /.login-box -->
<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- iCheck -->
<script src="<?php echo e(asset('plugins/iCheck/icheck.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass   : 'iradio_square-blue',
      increaseArea : '20%' // optional
    })
  })
</script>
<script type="text/javascript">
  toastr.options.preventDuplicates = true;
  <?php if(count($errors) > 0): ?>
          var err_msg = ""
          err_msg += "<ul>"
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  err_msg += "<li><?php echo e($error); ?></li>"
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          err_msg += "</ul>"
    toastr.error(err_msg);
  <?php endif; ?>
  <?php if(session('error')): ?>
    toastr.error("<?php echo e(session('error')); ?>");
  <?php endif; ?>
  <?php if(session('success')): ?>
    toastr.success("<?php echo e(session('success')); ?>");
  <?php endif; ?>

  <?php if(session('info')): ?>
    toastr.info("<?php echo e(session('info')); ?>");
  <?php endif; ?>
</script>

</body>
</html>
