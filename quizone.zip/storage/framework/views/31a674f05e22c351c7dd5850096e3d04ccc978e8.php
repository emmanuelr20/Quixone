<?php $__env->startSection('title'); ?>
    Select Subjects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark">Select Game Subject</h1>
              </div><!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="/">Home</a></li>
                  <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Play Now</a></li>
                  <li class="breadcrumb-item active">Select Subject</li>
                </ol>
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
    
        <!-- Main content -->
        <div class="content">
          <div class="container-fluid">
            <br>
            <div class="row">
                <div class="col-md-2"></div>
              <div class="col-lg-8">
                <div class="card">
                  <div class="card-body">
                    <h3 class="card-title">Select Subjects</h3>
                    <br>  
                    <div class="card-text">
                           <div class="funkyradio">
                               <form action="<?php echo e(route('start_quiz', $quiz_type->id)); ?>" method="POST">
                                   <?php echo e(csrf_field()); ?>

                                   <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($subject->ready($quiz_type->id)): ?>
                                        <div class="funkyradio-success">
                                            <input type="checkbox" class="<?php echo e($quiz_type->id == 1 ? 'multiple':'single'); ?>" name="subjects[]" id="checkbox<?php echo e($subject->id); ?>" value="<?php echo e($subject->id); ?>"/>
                                            <label for="checkbox<?php echo e($subject->id); ?>"><?php echo e(ucwords($subject->name)); ?></label>
                                        </div>
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button type="submit" id="proceed" href="#" class="card-link btn btn-primary pull-right">Proceed</button>
                               </form>
                           </div>
                       </div>
                      </div>
                  </div>
                </div>
              </div>
              </div>
            <!-- /.row --> 
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authenticated', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>