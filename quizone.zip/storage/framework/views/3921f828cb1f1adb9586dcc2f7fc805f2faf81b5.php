<?php $__env->startSection('title'); ?>
  Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-dark">Dashboard</h1>
            </div>
            <!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box">
                <span class="info-box-icon bg-info elevation-1"><i class="fa fa-list"></i></span>
                <a href="#" class="text-dark" data-toggle="modal" data-target="#game_type">
                  <div class="info-box-content">
                    <span class="info-box-text">Play Now</span>
                    <span class="info-box-number">Enter Competition</span>
                  </div>
                </a>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box mb-3">
                <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-money"></i></span>
                <a class="text-dark" href="<?php echo e(route('deposit')); ?>" >
                  <div class="info-box-content">
                    <span class="info-box-text">Deposit Now</span>
                    <span class="info-box-number">fund wallet</span>
                  </div>
                </a>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
            </div>
            <!-- /.col -->

            <!-- fix for small devices only -->
            <div class="clearfix hidden-md-up"></div>

            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box mb-3">
                <span class="info-box-icon bg-success elevation-1"><i class="fa fa-gamepad"></i></span>
                <a href="#" class="text-dark" data-toggle="modal" data-target="#game_type">
                  <div class="info-box-content">
                    <span class="info-box-text">Active Game Type </span>
                    <span class="info-box-number">
                      <?php $__empty_1 = true; $__currentLoopData = $quiz_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> 
                        <?php echo e($quiz_type->title); ?> &nbsp;&nbsp;&nbsp;&nbsp;
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                        No quiz available 
                      <?php endif; ?>
                    </span>
                  </div>
                </a>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box mb-3">
                <span class="info-box-icon bg-warning elevation-1"><i class="fa fa-money"></i></span>

                <div class="info-box-content">
                  <span class="info-box-text">Current Balance</span>
                  <span class="info-box-number"><?php echo e((int)auth()->user()->wallet); ?>.00</span>
                </div>
                <!-- /.info-box-content -->
              </div>
              <!-- /.info-box -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->

          <div class="row">
            <div class="col-md-3">

              <!-- Profile Image -->
              <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                  <div class="text-center">
                    <?php if(auth()->user()->avatar): ?>
                      <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('dist/img/' . auth()->user()->avatar)); ?>" alt="User profile picture">
                    <?php else: ?>
                      <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('dist/img/avatar.png')); ?>" alt="User profile picture">
                    <?php endif; ?>
                  </div>

                  <h3 class="profile-username text-center"><?php echo e(ucwords(auth()->user()->name)); ?></h3>

                  <p class="text-muted text-center"><?php echo e(auth()->user()->role()); ?></p>

                  <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item">
                      <b>Email </b> <a class="float-right"><?php echo e(auth()->user()->email); ?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Username </b> <a class="float-right"><?php echo e(strtolower(auth()->user()->username)); ?></a>
                    </li>
                    <li class="list-group-item">
                      <b>Phone num </b> <a class="float-right"><?php echo e(auth()->user()->phone); ?></a>
                    </li>
                  </ul>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
              <?php if(auth()->user()->is_admin): ?>
                  <h5>Toggle quiz type status</h5>
                  <div class="info-box mb-3">
                    <?php $__currentLoopData = $all_quiz_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-6">
                          <?php echo e($quiz_type->title); ?>

                          <div class="switch">
                            <input id="cmn-toggle-<?php echo e($quiz_type->id); ?>" class="cmn-toggle cmn-toggle-round-flat" type="checkbox" value="<?php echo e($quiz_type->id); ?>" <?php echo e($quiz_type->is_active ? 'checked': ''); ?>>
                            <label for="cmn-toggle-<?php echo e($quiz_type->id); ?>"></label>
                          </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
              <?php endif; ?>
              
            </div>
            <!-- /.col -->
            <div class="col-md-9">
              <div class="card">
                <div class="card-header p-2">
                  <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#account" data-toggle="tab">Update Profile Details</a></li>
                    <li class="nav-item"><a class="nav-link" href="#baccount" data-toggle="tab">Update Bank Details</a></li>
                    <li class="nav-item"><a class="nav-link" href="#password" data-toggle="tab">Change Password</a></li>
                    <li class="nav-item"><a class="nav-link" href="#deposit" id="deposit-trigger" data-toggle="tab">Deposit</a></li>
                  </ul>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content">
                    
                    <!-- user_details plane -->
                      <?php echo $__env->make('partials.planes.user_details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <!-- password plane -->
                      <?php echo $__env->make('partials.planes.password', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <!-- bank_details plane -->
                      <?php echo $__env->make('partials.planes.bank_details', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <!-- deposit plane -->
                      <?php echo $__env->make('partials.planes.deposit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <!-- /.tab-pane -->
                  </div>
                  <!-- /.tab-content -->
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.nav-tabs-custom -->
            </div>
            <!-- /.col -->
          </div>
        </div>
        <!--/. container-fluid -->
      </section>

      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
  console.log('Hey');
      let links=Array.from(document.querySelectorAll('a.disabled'));
      $(links).on('click',(evt)=>{
        evt.preventDefault();
      })
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authenticated', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>