<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Quizone | <?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('plugins/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/custom.css')); ?>">
  <link href="<?php echo e(asset('css/toastr.min.css')); ?>" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <div class="container">
    <ul class="navbar-nav">
      
      <li class="nav-item d-none d-sm-inline-block">
        <a href="/" class="nav-link active">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?php echo e(route('about')); ?>" class="nav-link">About</a>
      </li>
    </ul>

    <!-- SEARCH FORM -->
  

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <?php if(auth()->check()): ?>
      <li class="nav-item dropdown">
            <div class="info-box-content">
                <span class=""><i class="fa fa-money"></i> <?php echo e((int)auth()->user()->wallet); ?>.00</span>
            </div>
      </li>
      <?php endif; ?>
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
            <i class="fa fa-user"></i>
            <i class="fa fa-angle-down  "></i>
        </a>
          <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <?php if(auth()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-item">
                    <i class="fa fa-dashboard mr-2"></i> Dashboard
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('deposit')); ?>" class="dropdown-item">
                    <i class="fa fa-money mr-2"></i>Make Deposit
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item" data-target="#game_type" data-toggle="modal">
                    <i class="fa fa-gamepad mr-2"></i>Play Now
                </a>
                <div class="dropdown-divider"></div>
                    <a href="#" class="dropdown-item" data-target="#logout" data-toggle="modal">
                <i class="fa fa-power-off mr-2"></i> Logout
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="dropdown-item">
                    <i class="fa fa-envelope mr-2"></i> Login
                </a>
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('register')); ?>" class="dropdown-item">
                    <i class="fa fa-users mr-2"></i> Register
                </a>
            <?php endif; ?>
        </div>
        </li>

    </ul>
  </div>
  </nav>
  <!-- /.navbar -->

  <?php echo $__env->yieldContent('content'); ?>

  </div>
  <!-- /.content-wrapper -->
  <footer class="footer">
    <div class="container">
        <strong>Copyright &copy; 2018 <a href="/">QuizOne</a>.</strong> All rights reserved.
    </div>
  </footer>

    <?php if(auth()->check()): ?>
        <?php echo $__env->make('partials.modals.testimonies', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.modals.referral', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.modals.select_quiz', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('partials.modals.logout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.js')); ?>"></script> -->
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/js/custom.js')); ?>"></script>
<script type="text/javascript">
  toastr.options.preventDuplicates = true;
    <?php if(count($errors) > 0): ?>
            var err_msg = ""
            err_msg += "<ul>"
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    err_msg += "<li><?php echo e($error); ?></li>"
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            err_msg += "</ul>"
        toastr.error(err_msg);
    <?php endif; ?>
    <?php if(session('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>
    <?php if(session('success')): ?>
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if(session('info')): ?>
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>