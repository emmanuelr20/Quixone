<?php $__env->startSection('title'); ?> Password Reset <?php $__env->stopSection(); ?>
<?php $__env->startSection('name'); ?> login-page <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body login-card-body">
        <h5 class="login-box-msg">Reset Password</h5>
        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>" aria-label="<?php echo e(__('Reset Password')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group has-feedback">
                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="example@mail.com">
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="form-group row mb-0">
                <div class="col-md-8 offset-md-2">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">
                        <?php echo e(__('Send Password Reset Link')); ?>

                    </button>
                </div>
            </div>
            <br>
            <p class="mb-0 text-center">
                <a href="<?php echo e(route('login')); ?>" class="text-center">Go to Login</a>
            </p>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>