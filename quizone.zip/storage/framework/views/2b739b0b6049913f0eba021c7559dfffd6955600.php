<div class="row">
    <div class="col-lg-8">
        
        <div class="card">
        <div id="timer">
            <div id="left"></div>
        </div>
        <div class="card-body">
            <h6 class="card-subtitle mag10"><?php echo e($question->body); ?></h6>
            <br>  
            <div class="card-text">
                <div class="funkyradio">
                    <?php if(!$question->isGerman()): ?>
                        <?php $__currentLoopData = $question->options->sortBy('body'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="funkyradio-success">
                                <input type="radio" value="<?php echo e($option->id); ?>" name="answer" id="answer<?php echo e($option->id); ?>" />
                                <label for="answer<?php echo e($option->id); ?>"><?php echo e($option->body); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="option" >
                            <textarea class="form-control" name="answer" rows="7" placeholder="Type answer..." rows="2" id="answer" autofocus></textarea>
                        </p>
                    <?php endif; ?>
                    <input type="hidden" id="csrf" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" id="quiz-id" value="<?php echo e($quiz->id); ?>">
                </div>
            </div>
            <button class="card-link btn btn-primary pull-right" id="submit-answer">Next</button>
        </div>
        </div>
    </div>
    <div class="col-lg-4 circular-timer">
        <div class="card">
            <div class="card-body">
                <h6 class="card-subtitle mag10">Timer </h6>
                <div class="card-text"> 
                    <div class="container">
                        <div class="row">
                        <div class="progress blue">
                            <span class="progress-left">
                                <span class="progress-bar"></span>
                            </span>
                            <span class="progress-right">
                                <span class="progress-bar"></span>
                            </span>
                            <div class="progress-value" id="timer-value"></div>
                        </div>
                        </div>
                    </div>               
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.row --> 