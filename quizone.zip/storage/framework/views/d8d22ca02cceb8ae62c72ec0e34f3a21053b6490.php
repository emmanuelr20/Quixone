<?php $__env->startSection('title'); ?>
    Add Question
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Add New Question</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item">
                                    <a href="#">Home</a>
                                </li>
                                <li class="breadcrumb-item active">Set Exam</li>
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    <form action="<?php echo e(route('add_question')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Enter question and its option(s)</h5>
                                        <br>
                                        <div class="card-text">
                                            <div class="form-group">
                                                    <select name="subject" id="" class="form-control" required>
                                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($subject->id); ?>"> <?php echo e($subject->name); ?> </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                            </div>
                                        </div>

                                        <div class="card-text">
                                            <div class="form-group">
                                                <select name="question_level" id="" class="form-control" required>
                                                    <?php $__currentLoopData = $question_levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($question_level->id); ?>"><?php echo e($question_level->title); ?></option>                                                    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="card-text">
                                            <div class="form-group">
                                                <select name="quiz_type" id="" class="form-control" required>
                                                    <?php $__currentLoopData = $quiz_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($quiz_type->id); ?>"><?php echo e($quiz_type->title); ?></option>                                                    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="card-text">
                                            <div class="form-group">
                                                <select name="question_type" id="" class="form-control" required>
                                                    <?php $__currentLoopData = $question_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($question_type->id); ?>"><?php echo e($question_type->name); ?></option>                                                    
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="card-text">
                                            <div class="form-group">
                                                <textarea type="text" class="form-control<?php echo e($errors->has('body') ? ' is-invalid' : ''); ?>" rows="5" cols="10" name="body" placeholder="Question" required><?php echo e(old('body')); ?></textarea>
                                                <?php if($errors->has('body')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('body')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="card-text">
                                            <div class="form-group">
                                                <input id="newPass" type="text" class="form-control<?php echo e($errors->has('answer') ? ' is-invalid' : ''); ?>" name="answer" value="<?php echo e(old('answer')); ?>" placeholder="Answer"required>
                                                <?php if($errors->has('answer')): ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($errors->first('answer')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="card-text">
                                            <p class="text-info"><small><b>* ignore options if question type is german</b></small></p>
                                            <div class="form-inline">
                                                <?php for($i = 0; $i<3; $i++): ?>
                                                    <input id="" type="text" class="form-control<?php echo e($errors->has('options') ? ' is-invalid' : ''); ?> col-md-4" name="options[]" value="<?php echo e(old('options.' . $i)); ?>" placeholder="option <?php echo e($i+1); ?>">
                                                    <?php if($errors->has('options')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('options')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                <?php endfor; ?> 
                                            </div>
                                        </div>

                                        <br>
                                        <a href="#" class="card-link pull-right"><button type="submit" class="btn btn-primary">Submit</button></a>
                                    </div>
                                </div>

                            </div>
                            <!-- /.col-md-6 -->

                        </div>
                        <!-- /.row -->
                    </form>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authenticated', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>