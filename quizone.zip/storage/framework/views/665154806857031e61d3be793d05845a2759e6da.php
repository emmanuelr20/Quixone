<div class="tab-pane active" id="account">
        <form class="form-horizontal" action="<?php echo e(route('update_profile')); ?>" method="POST">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="accName" class="col-sm-6 control-label"> Full Name </label>

            <div class="col-sm-10">
              <input id="accName" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(auth()->user()->name); ?>" required autofocus>
              <?php if($errors->has('name')): ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('name')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="form-group">
            <label for="email" class="col-sm-6 control-label"> Email </label>

            <div class="col-sm-10">
              <input type="email" class="form-control" id="accNum" name="email" value="<?php echo e(auth()->user()->email); ?>" disabled>
            </div>
          </div>
          <div class="form-group">
            <label for="uname" class="col-sm-6 control-label">Username</label>

            <div class="col-sm-10">
              <input id="uname" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(auth()->user()->username); ?>" required>
              <?php if($errors->has('username')): ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('username')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
          </div>

          <div class="form-group">
            <label for="pnum" class="col-sm-6 control-label"> Phone Number </label>

            <div class="col-sm-10">
              <input id="pnum" type="number" class="form-control<?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" value="<?php echo e(auth()->user()->phone); ?>" required>
              <?php if($errors->has('phone')): ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($errors->first('phone')); ?></strong>
                  </span>
              <?php endif; ?>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-danger">Update</button>
            </div>
          </div>
        </form>
      </div>