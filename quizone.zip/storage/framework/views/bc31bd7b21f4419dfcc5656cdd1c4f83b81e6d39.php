<?php $__env->startSection('title'); ?>
    Select Subjects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark">Quiz Page</h1>
              </div><!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item"><a href="#">Play Now</a></li>
                  <li class="breadcrumb-item active">Quiz</li>
                </ol>
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
    
        <!-- Main content -->
        <div class="content">
          <div class="container-fluid">
            <br>
            <div id="exam-space">
              <?php echo $__env->make('partials.exams', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="<?php echo e(asset('dist/js/exam.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authenticated', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>