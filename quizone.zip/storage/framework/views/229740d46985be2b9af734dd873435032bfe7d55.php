<?php $__env->startSection('title'); ?>
    Unpaid Winners
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark"><?php echo e($status); ?> Winners</h1>
              </div><!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="/">Home</a></li>
                  <li class="breadcrumb-item active"><?php echo e($status); ?> Winners</li>
                </ol>
              </div><!-- /.col -->
            </div><!-- /.row -->
          </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
    
        <!-- Main content -->
        <div class="content">
         <!-- Default box -->
         <div class="card">
                <div class="card-header border-transparent">
                  <h3 class="card-title">List of <?php echo e($status); ?> Winners</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table m-0">
                      <thead>
                      <tr>
                        <th> # </th>
                        <th>Users Email</th>
                        <th>Phone</th>
                        <th>Game type</th>
                        <th>Amount</th>
                        <?php if($status == 'Unpaid'): ?>
                          <th>Mark as paid</th>
                        <?php endif; ?>
                      </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($quiz->id); ?></td>
                                <td><a href="#" data-toggle="modal" data-target="#info<?php echo e($quiz->id); ?>"><?php echo e($quiz->user->email); ?></a></td>
                                <td><?php echo e($quiz->user->phone); ?></td>
                                <td><?php echo e($quiz->quiz_type->title); ?></td>
                                <td><?php echo e($quiz->quiz_type->id == 2 ? '5000' : '10000'); ?></td>   
                                <?php if($status == 'Unpaid'): ?>
                                  <td><a href="<?php echo e(route('mark_paid', $quiz->id)); ?>" class="text-center"><i class="fa fa-2x fa-check text-primary"></i></a></td>                                                  
                                <?php endif; ?>          
                            </tr>
                            <?php echo $__env->make('partials.modals.infocard', ['user' => $quiz->user, 'id' => $quiz->id], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                  <!-- /.table-responsive -->
                </div>
                <!-- /.card-body -->
                <div class="card-footer clearfix">
                    <?php echo e($quizzes->links()); ?>

                </div>
                <!-- /.card-footer -->
              </div>
              <!-- /.card -->
        </div>
        <!-- /.content -->
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.authenticated', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>