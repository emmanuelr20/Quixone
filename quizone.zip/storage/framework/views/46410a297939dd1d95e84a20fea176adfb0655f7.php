<div class="tab-pane" id="password">
    <form class="form-horizontal" action="<?php echo e(route('change_password')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <label for="oldPass" class="col-sm-6 control-label">Old Password</label>
            <div class="col-sm-10">
                <input id="oldPass" type="password" class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" name="old_password" placeholder="Old Password"required>
                <?php if($errors->has('old_password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('old_password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group">
            <label for="newPass" class="col-sm-6 control-label">New Password</label>
            <div class="col-sm-10">
                <input id="newPass" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="New Password"required>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
        <div class="form-group">
        <label for="newPass2" class="col-sm-6 control-label">Confirm New Password</label>

        <div class="col-sm-10">
                <input  required class="form-control" id="newPass2" type="password" name="password_confirmation"  placeholder="Confirm New Password" required>
        </div>
        </div>
        <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-danger">Submit</button>
        </div>
        </div>
    </form>
</div>